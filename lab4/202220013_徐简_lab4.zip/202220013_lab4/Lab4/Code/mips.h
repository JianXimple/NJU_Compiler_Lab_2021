void initOffset();
void code_generate(const char* fielname);